
int callCount = 5;

int someFunction()
{
    //do something

    callCount++;
}
