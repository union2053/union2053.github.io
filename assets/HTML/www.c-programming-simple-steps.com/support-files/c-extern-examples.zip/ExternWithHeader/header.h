extern int callCount;

void someFunction();
