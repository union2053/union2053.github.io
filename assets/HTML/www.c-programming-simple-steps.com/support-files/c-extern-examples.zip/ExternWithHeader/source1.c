int callCount = 0;

void someFunction()
{
    callCount++;

    // do some stuff here
}
