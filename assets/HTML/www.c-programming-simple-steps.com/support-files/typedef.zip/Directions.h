typedef enum DirectionTAG
{
	North,
	East,
	Southm,
	West
} DIRECTION;