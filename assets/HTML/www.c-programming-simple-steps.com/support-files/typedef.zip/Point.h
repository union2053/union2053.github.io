typedef struct PointTAG
{
	int x;
	int y;
} POINT;
