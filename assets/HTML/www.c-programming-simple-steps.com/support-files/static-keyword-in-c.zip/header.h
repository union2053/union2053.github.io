#include<stdio.h>

void count();
void printArray(int myArray[], int size);
void printVars();

extern int num1;
extern int num2;