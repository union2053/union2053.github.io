struct Employee
{
	struct Address address;
	char name[30];
	int age;
};