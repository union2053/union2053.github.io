struct Address
{
	char country[30];
	char city[30];
	char street[30];
	char addressField[30];
};