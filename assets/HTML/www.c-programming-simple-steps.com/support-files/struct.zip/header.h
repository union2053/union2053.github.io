#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include"structA.h"
#include"structB.h"
#include"address.h";
#include"employee.h";

void inputEmployee(struct Employee* worker);
void inputAddress(struct Address* address);
void outputEmployee(struct Employee worker);
void outputAddress(struct Address address);