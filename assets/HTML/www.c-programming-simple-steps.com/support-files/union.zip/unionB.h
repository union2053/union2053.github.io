union B
{
	char symbol;
	int number;
	float numbers[3];
};