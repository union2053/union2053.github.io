#include<stdio.h>

#include"unionA.h"
#include"unionB.h"

void simpleUnion();
void notSoSimpleUnion();