	union A
	{
		char a;
		char b;
		char c;
		char d;
	};